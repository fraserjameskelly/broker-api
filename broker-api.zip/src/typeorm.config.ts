// import { __prod__ } from './constants';
import { Policy } from './entity/Policy';
import path from 'path';
import { PolicyType } from './entity/PolicyType';
import { Insurer } from './entity/Insurer';
import { ConnectionOptions } from 'typeorm';

export default {
    type: 'mysql',
    host: 'localhost',
    port: 3306,
    username: 'root',
    password: '',
    database: 'broker-api',
    synchronize: true,
    logging: false,
    entities: [
        Policy, Insurer, PolicyType
    ],
    migrations: [
        path.join(__dirname, './migration/*.js')
    ],
    subscribers: [
        path.join(__dirname, './subscriber/*.js')
    ],
    migrationsRun: true,
    cli: {
        entitiesDir: 'src/entity',
        migrationsDir: 'src/migration',
        subscribersDir: 'src/subscriber',
    },
} as ConnectionOptions;
